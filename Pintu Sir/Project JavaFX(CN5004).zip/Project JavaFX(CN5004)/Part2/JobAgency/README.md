## Introduction

This is a GUI application to maintain jobs and jobseekers for an agency.

## Usage

First, Run the App class, it will open an interface for maintaining the data of job vacencies and job seekers.

## Warning

Do not delete or move any text file.
